from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixas de valores entre 0 e 230 mm com gradiente de azuis ('Blues')
valores = [0, 25, 50, 75, 100, 125, 150, 175, 200, 230]
cores = [
    "#f7fbff", "#deebf7", "#c6dbef", "#9ecae1",
    "#6baed6", "#4292c6", "#2171b5", "#08519c", "#08306b", "#041f40"
]

for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")
        shader_items = [
            QgsColorRampShader.ColorRampItem(v, QColor(c), f"{v} mm")
            for v, c in zip(valores, cores)
        ]
        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min(valores))
        shader.setMaximumValue(max(valores))
        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)
        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Precipitação – SSP245 (2061–2080) – escala de 0 a 230 mm.")
