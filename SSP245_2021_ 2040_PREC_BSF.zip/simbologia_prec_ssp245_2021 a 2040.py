from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixas de 0 a 250 mm com paleta de cores 'Blues'
valores = [0, 25, 50, 75, 100, 125, 150, 175, 200, 225, 250]
cores = [
    "#f7fbff", "#e3eef9", "#cfe1f3", "#bdd4ec", "#9ecae1",
    "#6baed6", "#4292c6", "#2171b5", "#08519c", "#08306b", "#041f40"
]

for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")
        shader_items = [
            QgsColorRampShader.ColorRampItem(val, QColor(cor), f"{val} mm")
            for val, cor in zip(valores, cores)
        ]
        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min(valores))
        shader.setMaximumValue(max(valores))
        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)
        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Precipitação – faixa de 0 a 250 mm.")
