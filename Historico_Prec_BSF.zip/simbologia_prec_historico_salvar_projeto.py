from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixa de precipitação: 0 a 290 mm
min_prec = 0
max_prec = 290

# Paleta 'Blues' interpolada
cores_prec = [
    (0, QColor("#f7fbff")),
    (30, QColor("#deebf7")),
    (60, QColor("#c6dbef")),
    (90, QColor("#9ecae1")),
    (120, QColor("#6baed6")),
    (150, QColor("#4292c6")),
    (180, QColor("#2171b5")),
    (220, QColor("#08519c")),
    (260, QColor("#08306b")),
    (290, QColor("#041f40"))
]

# Aplicar simbologia
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer and "precipitação histórica" in layer.name().lower():
        print(f"🎨 Estilizando: {layer.name()}")
        shader_items = [
            QgsColorRampShader.ColorRampItem(valor, cor, f"{valor} mm")
            for valor, cor in cores_prec
        ]

        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_prec)
        shader.setMaximumValue(max_prec)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Precipitação histórica – escala 0 a 290 mm.")
