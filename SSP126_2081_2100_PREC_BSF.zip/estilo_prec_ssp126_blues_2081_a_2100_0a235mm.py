from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

# Faixa de precipitação: 5 a 260 mm
min_prec = 0.0
max_prec = 235.0

# Paleta inspirada no esquema "Blues"
cores_blues = [
    (0, QColor("#f7fbff")),
    (30, QColor("#deebf7")),
    (60, QColor("#c6dbef")),
    (90, QColor("#9ecae1")),
    (120, QColor("#6baed6")),
    (150, QColor("#4292c6")),
    (180, QColor("#2171b5")),
    (210, QColor("#08519c")),
    (235, QColor("#08306b"))
]

# Aplicar simbologia a todas as camadas raster
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")

        shader_items = []
        for valor, cor in cores_blues:
            shader_items.append(QgsColorRampShader.ColorRampItem(valor, cor, f"{valor:.0f} mm"))

        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_prec)
        shader.setMaximumValue(max_prec)

        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)

        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

        print(f"✅ Estilo aplicado com faixa 0–235 mm a: {layer.name()}")

print("🎯 Estilização concluída com a paleta 'Blues' para Precipitação.")