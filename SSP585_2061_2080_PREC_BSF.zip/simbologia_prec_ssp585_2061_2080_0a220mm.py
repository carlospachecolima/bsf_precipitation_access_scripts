from qgis.core import (
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer
)
from PyQt5.QtGui import QColor

min_prec = 0
max_prec = 220

cores_prec = [
    (0, QColor("#f7fbff")),
    (30, QColor("#deebf7")),
    (60, QColor("#c6dbef")),
    (90, QColor("#9ecae1")),
    (120, QColor("#6baed6")),
    (150, QColor("#4292c6")),
    (180, QColor("#2171b5")),
    (200, QColor("#08519c")),
    (220, QColor("#08306b"))
]

for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        print(f"🎨 Estilizando: {layer.name()}")
        shader_items = [
            QgsColorRampShader.ColorRampItem(valor, cor, f"{valor} mm")
            for valor, cor in cores_prec
        ]
        shader = QgsColorRampShader()
        shader.setColorRampType(QgsColorRampShader.Interpolated)
        shader.setColorRampItemList(shader_items)
        shader.setMinimumValue(min_prec)
        shader.setMaximumValue(max_prec)
        raster_shader = QgsRasterShader()
        raster_shader.setRasterShaderFunction(shader)
        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, raster_shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        print(f"✅ Estilo aplicado a: {layer.name()}")

print("🎯 Estilização concluída para Precipitação – SSP585 (2061–2080) – 0 a 220 mm.")