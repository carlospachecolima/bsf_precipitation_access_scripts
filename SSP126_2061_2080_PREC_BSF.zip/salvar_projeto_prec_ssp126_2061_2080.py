import os
from qgis.core import QgsProject

caminho_projeto = r"E:/Projeto GeoBSF/Access/Prec/2061 a 2080/SSP126/Prec_SSP126_2061_2080.qgz"

os.makedirs(os.path.dirname(caminho_projeto), exist_ok=True)

if QgsProject.instance().write(caminho_projeto):
    print(f"💾 Projeto salvo com sucesso em: {caminho_projeto}")
else:
    print(f"⚠️ Erro ao salvar o projeto em: {caminho_projeto}")