import os
from qgis.core import (
    QgsProject,
    QgsProcessingFeedback,
    QgsRasterLayer,
    QgsVectorLayer
)
from qgis.utils import iface
import processing

# Dicionário de correspondência número → mês
numero_para_mes = {
    "01": "jan", "02": "fev", "03": "mar", "04": "abr",
    "05": "mai", "06": "jun", "07": "jul", "08": "ago",
    "09": "set", "10": "out", "11": "nov", "12": "dez"
}

# Caminho da pasta de saída
diretorio_saida = "E:/Projeto GeoBSF/Access/Prec/Historico"

# Garante que o diretório exista
if not os.path.exists(diretorio_saida):
    os.makedirs(diretorio_saida)

# Obtém todas as camadas carregadas no QGIS
project = QgsProject.instance()
layers = list(project.mapLayers().values())

# Identifica a camada vetor (shapefile) no projeto
vector_layer = next((layer for layer in layers if isinstance(layer, QgsVectorLayer)), None)

# Verifica se encontrou a camada vetor
if not vector_layer:
    print("Erro: Nenhuma camada shapefile encontrada no projeto.")
else:
    print(f"Shapefile encontrado: {vector_layer.name()}")

    # Para cada camada raster no projeto
    for layer in layers:
        if isinstance(layer, QgsRasterLayer):
            nome_original = layer.name().lower().strip()

            # Checar se algum número do dicionário está no nome
            for numero, mes in numero_para_mes.items():
                if f"_{numero}" in nome_original:
                    novo_nome = f"Precipitação histórica (mm)_{mes}"
                    print(f"🔄 Processando: {nome_original} → {novo_nome}")

                    # Define o caminho de saída
                    caminho_saida = os.path.join(diretorio_saida, f"{novo_nome}.tif")

                    # Configura os parâmetros do processamento
                    params = {
                        'INPUT': layer,
                        'MASK': vector_layer,
                        'TARGET_EXTENT': vector_layer.extent(),
                        'NODATA': 10000000,
                        'DATA_TYPE': 0,
                        'ALPHA_BAND': False,
                        'CROP_TO_CUTLINE': True,
                        'KEEP_RESOLUTION': True,
                        'OUTPUT': caminho_saida
                    }

                    # Executa o recorte
                    try:
                        feedback = QgsProcessingFeedback()
                        processing.run("gdal:cliprasterbymasklayer", params, feedback=feedback)
                        print(f"✅ Salvo: {caminho_saida}")
                        iface.addRasterLayer(caminho_saida, novo_nome)
                        print(f"📂 Adicionado ao projeto: {novo_nome}")
                    except Exception as e:
                        print(f"⚠️ Erro ao processar {nome_original}: {str(e)}")

                    break
            else:
                print(f"⏭️ Ignorado: {nome_original}")