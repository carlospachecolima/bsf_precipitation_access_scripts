from qgis.core import QgsProject

# Dicionário com os meses abreviados
meses = {
    "jan": "jan", "fev": "fev", "mar": "mar", "abr": "abr", "mai": "mai", "jun": "jun",
    "jul": "jul", "ago": "ago", "set": "set", "out": "out", "nov": "nov", "dez": "dez"
}

# Verifica cada camada no projeto
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        nome_original = layer.name().lower()
        for abrev in meses:
            if abrev in nome_original:
                novo_nome = f"Precipitação (mm)_{abrev}"
                layer.setName(novo_nome)
                print(f"✅ Camada renomeada para: {novo_nome}")
                break
