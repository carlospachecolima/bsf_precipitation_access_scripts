from qgis.core import QgsProject

# Lista de meses válidos no padrão usado nos nomes de arquivos
meses_validos = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']

# Percorre todas as camadas do projeto
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() == layer.RasterLayer:
        nome_original = layer.name().lower()
        for mes in meses_validos:
            if mes in nome_original:
                novo_nome = f"Precipitação (mm)_{mes}"
                layer.setName(novo_nome)
                print(f"✅ {nome_original} → {novo_nome}")
                break  # evita múltiplas substituições
