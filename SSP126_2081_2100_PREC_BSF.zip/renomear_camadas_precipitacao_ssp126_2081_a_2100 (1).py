from qgis.core import QgsProject

# Lista dos meses em ordem
meses_abrev = [
    "jan", "fev", "mar", "abr", "mai", "jun",
    "jul", "ago", "set", "out", "nov", "dez"
]

# Loop pelas camadas abertas
for layer in QgsProject.instance().mapLayers().values():
    if layer.type() != layer.RasterLayer:
        continue

    nome_original = layer.name().lower().strip()

    for mes in meses_abrev:
        if mes in nome_original and not nome_original.startswith("precipitação"):
            novo_nome = f"Precipitação (mm)_{mes}"
            layer.setName(novo_nome)
            print(f"🔄 Renomeado: {nome_original} → {novo_nome}")
            break
    else:
        print(f"⏭️ Ignorado: {nome_original}")
