from qgis.core import (
    QgsProject, QgsLayoutItemLabel, QgsLayoutItemMap,
    QgsPrintLayout, QgsLayoutExporter, QgsReadWriteContext, QgsRasterLayer
)
from qgis.PyQt.QtXml import QDomDocument
import os
import re

saida = r"E:/Projeto GeoBSF/Access/Prec/2021 a 2040/SSP126/Layouts"
os.makedirs(saida, exist_ok=True)

meses = {
    "jan": "janeiro", "fev": "fevereiro", "mar": "março", "abr": "abril",
    "mai": "maio", "jun": "junho", "jul": "julho", "ago": "agosto",
    "set": "setembro", "out": "outubro", "nov": "novembro", "dez": "dezembro"
}

padrao = re.compile(r"^Precipitação \(mm\)_(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)$", re.IGNORECASE)

template_path = r"E:/Projeto GeoBSF/Access/Tmax/2021 a 2040/SSP245/Modelo Tmax BSF.qpt"

with open(template_path, 'r', encoding='utf-8') as f:
    template_content = f.read()

for layer in QgsProject.instance().mapLayers().values():
    if isinstance(layer, QgsRasterLayer) and padrao.match(layer.name()):
        nome = layer.name()
        mes_abrev = padrao.match(nome).group(1)
        mes_extenso = meses[mes_abrev]

        project = QgsProject.instance()
        layout = QgsPrintLayout(project)
        layout.initializeDefaults()
        document = QDomDocument()
        document.setContent(template_content)
        layout.readLayoutXml(document.documentElement(), document, QgsReadWriteContext())
        layout.setName(f"Layout_{mes_extenso}")

        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel) and "Temperatura máxima projetada" in item.text():
                item.setText(f"Precipitação projetada (2021 a 2040) – SSP126 – mês de {mes_extenso} – Região do Baixo São Francisco")
                item.refresh()

        for item in layout.items():
            if isinstance(item, QgsLayoutItemMap):
                item.setLayers([layer])
                item.zoomToExtent(layer.extent())
                item.refresh()

        caminho_saida = os.path.join(saida, f"Prec_SSP126_2021_2040_{mes_extenso}.png")
        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.ImageExportSettings()
        exporter.exportToImage(caminho_saida, settings)

        QgsProject.instance().removeMapLayer(layer)

print("🌧️ Layouts gerados para Precipitação – SSP126 (2021-2040).")
